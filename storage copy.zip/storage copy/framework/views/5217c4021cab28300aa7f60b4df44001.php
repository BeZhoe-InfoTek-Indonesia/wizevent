<?php $user = $user ?? auth()->user(); ?>
<div class="min-h-screen overflow-x-hidden dark:bg-gray-900" x-data="{ activeTab: '<?php echo e($initialProfileTab ?? ''); ?>' }" x-init="activeTab = activeTab || (new URLSearchParams(window.location.search).get('tab')) || localStorage.getItem('profileActiveTab') || 'dashboard'; $watch('activeTab', value => localStorage.setItem('profileActiveTab', value))">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div class="flex flex-col lg:flex-row gap-6">
            <!-- Sidebar -->
            <aside class="lg:w-72 flex-shrink-0 space-y-6">
                <!-- User Profile Card -->
                <div class="glass-panel rounded-3xl shadow-float p-6 text-center bg-white/80 dark:bg-gray-800/80 relative overflow-hidden group">
                    <div class="absolute -right-10 -top-10 w-32 h-32 bg-red-500/5 rounded-full blur-3xl group-hover:scale-150 transition-transform duration-1000"></div>
                    
                    <div class="relative inline-block mb-6">
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($user && $user->avatar): ?>
                            <div class="p-1.5 rounded-full bg-gradient-to-tr from-red-500 via-orange-400 to-red-600 shadow-xl group-hover:rotate-6 transition-transform duration-500">
                                <img class="h-28 w-28 rounded-full object-cover border-4 border-white dark:border-gray-800 shadow-inner" src="<?php echo e(Storage::url($user->avatar)); ?>" alt="<?php echo e($user->name); ?>">
                            </div>
                        <?php else: ?>
                            <div class="h-28 w-28 rounded-full bg-gradient-to-br from-red-500 to-red-600 flex items-center justify-center mx-auto border-4 border-white dark:border-gray-800 shadow-skeuo group-hover:rotate-6 transition-all duration-500">
                                <span class="text-4xl text-white font-black tracking-tighter"><?php echo e($user ? strtoupper(substr($user->name, 0, 1)) : ''); ?></span>
                            </div>
                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        <div class="absolute bottom-1.5 right-1.5 bg-green-500 rounded-full p-2 border-4 border-white dark:border-gray-800 shadow-lg">
                            <svg class="w-3.5 h-3.5 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="3" d="M5 13l4 4L19 7"></path>
                            </svg>
                        </div>
                    </div>
                    
                    <h3 class="font-black text-gray-900 dark:text-gray-100 text-2xl tracking-tighter"><?php echo e($user?->name); ?></h3>
                    <div class="inline-flex items-center gap-1.5 px-3 py-1 bg-gray-50 dark:bg-gray-900/50 rounded-full border border-gray-100 dark:border-gray-700 mt-2 mb-6 shadow-sm">
                        <span class="w-1.5 h-1.5 bg-green-500 rounded-full"></span>
                        <span class="text-[10px] font-black text-gray-500 dark:text-gray-400 uppercase tracking-[0.2em]"><?php echo e(__('profile.verified_member')); ?></span>
                    </div>
                    
                    <button type="button" @click="activeTab = 'account'" class="glass-btn-primary w-full py-4 rounded-2xl text-xs font-black uppercase tracking-widest active:scale-95 transition-all shadow-lg">
                        <?php echo e(__('profile.edit_profile')); ?>

                    </button>
                </div>

                <!-- Navigation Menu -->
                <nav role="tablist" aria-orientation="vertical" class="glass-panel p-2.5 rounded-[2rem] shadow-float bg-white/60 dark:bg-gray-800/60 transition-all">
                    <div class="space-y-1.5">
                        <?php if (isset($component)) { $__componentOriginala4967aab09e85417f0a3921527253ee6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala4967aab09e85417f0a3921527253ee6 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.profile.nav-item','data' => ['label' => ''.e(__('profile.dashboard')).'','tab' => 'dashboard','icon' => 'M4 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2V6zM14 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2V6zM4 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2v-2zM14 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2v-2z']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('profile.nav-item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => ''.e(__('profile.dashboard')).'','tab' => 'dashboard','icon' => 'M4 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2V6zM14 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2V6zM4 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2v-2zM14 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2v-2z']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala4967aab09e85417f0a3921527253ee6)): ?>
<?php $attributes = $__attributesOriginala4967aab09e85417f0a3921527253ee6; ?>
<?php unset($__attributesOriginala4967aab09e85417f0a3921527253ee6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala4967aab09e85417f0a3921527253ee6)): ?>
<?php $component = $__componentOriginala4967aab09e85417f0a3921527253ee6; ?>
<?php unset($__componentOriginala4967aab09e85417f0a3921527253ee6); ?>
<?php endif; ?>
                        <?php if (isset($component)) { $__componentOriginala4967aab09e85417f0a3921527253ee6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala4967aab09e85417f0a3921527253ee6 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.profile.nav-item','data' => ['label' => ''.e(__('profile.account')).'','tab' => 'account','icon' => 'M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('profile.nav-item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => ''.e(__('profile.account')).'','tab' => 'account','icon' => 'M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala4967aab09e85417f0a3921527253ee6)): ?>
<?php $attributes = $__attributesOriginala4967aab09e85417f0a3921527253ee6; ?>
<?php unset($__attributesOriginala4967aab09e85417f0a3921527253ee6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala4967aab09e85417f0a3921527253ee6)): ?>
<?php $component = $__componentOriginala4967aab09e85417f0a3921527253ee6; ?>
<?php unset($__componentOriginala4967aab09e85417f0a3921527253ee6); ?>
<?php endif; ?>
                        <?php if (isset($component)) { $__componentOriginala4967aab09e85417f0a3921527253ee6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala4967aab09e85417f0a3921527253ee6 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.profile.nav-item','data' => ['label' => ''.e(__('profile.your_reviews')).'','tab' => 'reviews','icon' => 'M11.049 2.927c.3-.921 1.603-.921 1.902 0l1.519 4.674a1 1 0 00.95.69h4.915c.969 0 1.371 1.24.588 1.81l-3.976 2.888a1 1 0 00-.363 1.118l1.518 4.674c.3.922-.755 1.688-1.538 1.118l-3.976-2.888a1 1 0 00-1.176 0l-3.976 2.888c-.783.57-1.838-.197-1.538-1.118l1.518-4.674a1 1 0 00-.363-1.118l-3.976-2.888c-.784-.57-.38-1.81.588-1.81h4.914a1 1 0 00.951-.69l1.519-4.674z']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('profile.nav-item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => ''.e(__('profile.your_reviews')).'','tab' => 'reviews','icon' => 'M11.049 2.927c.3-.921 1.603-.921 1.902 0l1.519 4.674a1 1 0 00.95.69h4.915c.969 0 1.371 1.24.588 1.81l-3.976 2.888a1 1 0 00-.363 1.118l1.518 4.674c.3.922-.755 1.688-1.538 1.118l-3.976-2.888a1 1 0 00-1.176 0l-3.976 2.888c-.783.57-1.838-.197-1.538-1.118l1.518-4.674a1 1 0 00-.363-1.118l-3.976-2.888c-.784-.57-.38-1.81.588-1.81h4.914a1 1 0 00.951-.69l1.519-4.674z']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala4967aab09e85417f0a3921527253ee6)): ?>
<?php $attributes = $__attributesOriginala4967aab09e85417f0a3921527253ee6; ?>
<?php unset($__attributesOriginala4967aab09e85417f0a3921527253ee6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala4967aab09e85417f0a3921527253ee6)): ?>
<?php $component = $__componentOriginala4967aab09e85417f0a3921527253ee6; ?>
<?php unset($__componentOriginala4967aab09e85417f0a3921527253ee6); ?>
<?php endif; ?>
                        <?php if (isset($component)) { $__componentOriginala4967aab09e85417f0a3921527253ee6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala4967aab09e85417f0a3921527253ee6 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.profile.nav-item','data' => ['label' => ''.e(__('profile.wishlist')).'','tab' => 'wishlist','icon' => 'M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('profile.nav-item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => ''.e(__('profile.wishlist')).'','tab' => 'wishlist','icon' => 'M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala4967aab09e85417f0a3921527253ee6)): ?>
<?php $attributes = $__attributesOriginala4967aab09e85417f0a3921527253ee6; ?>
<?php unset($__attributesOriginala4967aab09e85417f0a3921527253ee6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala4967aab09e85417f0a3921527253ee6)): ?>
<?php $component = $__componentOriginala4967aab09e85417f0a3921527253ee6; ?>
<?php unset($__componentOriginala4967aab09e85417f0a3921527253ee6); ?>
<?php endif; ?>
                        <?php if (isset($component)) { $__componentOriginala4967aab09e85417f0a3921527253ee6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala4967aab09e85417f0a3921527253ee6 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.profile.nav-item','data' => ['label' => ''.e(__('profile.your_orders')).'','tab' => 'orders','icon' => 'M16 11V7a4 4 0 00-8 0v4M5 9h14l1 12H4L5 9z']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('profile.nav-item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => ''.e(__('profile.your_orders')).'','tab' => 'orders','icon' => 'M16 11V7a4 4 0 00-8 0v4M5 9h14l1 12H4L5 9z']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala4967aab09e85417f0a3921527253ee6)): ?>
<?php $attributes = $__attributesOriginala4967aab09e85417f0a3921527253ee6; ?>
<?php unset($__attributesOriginala4967aab09e85417f0a3921527253ee6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala4967aab09e85417f0a3921527253ee6)): ?>
<?php $component = $__componentOriginala4967aab09e85417f0a3921527253ee6; ?>
<?php unset($__componentOriginala4967aab09e85417f0a3921527253ee6); ?>
<?php endif; ?>
                        <?php if (isset($component)) { $__componentOriginala4967aab09e85417f0a3921527253ee6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala4967aab09e85417f0a3921527253ee6 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.profile.nav-item','data' => ['label' => ''.e(__('profile.help_center')).'','tab' => 'help','icon' => 'M8.228 9c.549-1.165 2.03-2 3.772-2 2.21 0 4 1.343 4 3 0 1.4-1.278 2.575-3.006 2.907-.542.104-.994.54-.994 1.093m0 3h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z','isNew' => 'true']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('profile.nav-item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => ''.e(__('profile.help_center')).'','tab' => 'help','icon' => 'M8.228 9c.549-1.165 2.03-2 3.772-2 2.21 0 4 1.343 4 3 0 1.4-1.278 2.575-3.006 2.907-.542.104-.994.54-.994 1.093m0 3h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z','isNew' => 'true']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala4967aab09e85417f0a3921527253ee6)): ?>
<?php $attributes = $__attributesOriginala4967aab09e85417f0a3921527253ee6; ?>
<?php unset($__attributesOriginala4967aab09e85417f0a3921527253ee6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala4967aab09e85417f0a3921527253ee6)): ?>
<?php $component = $__componentOriginala4967aab09e85417f0a3921527253ee6; ?>
<?php unset($__componentOriginala4967aab09e85417f0a3921527253ee6); ?>
<?php endif; ?>
                        <?php if (isset($component)) { $__componentOriginala4967aab09e85417f0a3921527253ee6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala4967aab09e85417f0a3921527253ee6 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.profile.nav-item','data' => ['label' => ''.e(__('profile.settings')).'','tab' => 'settings','icon' => 'M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('profile.nav-item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => ''.e(__('profile.settings')).'','tab' => 'settings','icon' => 'M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala4967aab09e85417f0a3921527253ee6)): ?>
<?php $attributes = $__attributesOriginala4967aab09e85417f0a3921527253ee6; ?>
<?php unset($__attributesOriginala4967aab09e85417f0a3921527253ee6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala4967aab09e85417f0a3921527253ee6)): ?>
<?php $component = $__componentOriginala4967aab09e85417f0a3921527253ee6; ?>
<?php unset($__componentOriginala4967aab09e85417f0a3921527253ee6); ?>
<?php endif; ?>
                    </div>
                </nav>
            </aside>

            <!-- Main Content -->
            <main class="flex-1 min-w-0">
                <?php echo $__env->yieldContent('profile-content'); ?>
            </main>
        </div>
    </div>
    <?php if (isset($component)) { $__componentOriginal8a8716efb3c62a45938aca52e78e0322 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8a8716efb3c62a45938aca52e78e0322 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.footer','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('footer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8a8716efb3c62a45938aca52e78e0322)): ?>
<?php $attributes = $__attributesOriginal8a8716efb3c62a45938aca52e78e0322; ?>
<?php unset($__attributesOriginal8a8716efb3c62a45938aca52e78e0322); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8a8716efb3c62a45938aca52e78e0322)): ?>
<?php $component = $__componentOriginal8a8716efb3c62a45938aca52e78e0322; ?>
<?php unset($__componentOriginal8a8716efb3c62a45938aca52e78e0322); ?>
<?php endif; ?>
</div>
<?php /**PATH /Users/dwipurwanto/Sites/sites/freelance/event-management/resources/views/layouts/profile-layout.blade.php ENDPATH**/ ?>