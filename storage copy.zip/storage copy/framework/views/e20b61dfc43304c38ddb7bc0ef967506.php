<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['tab', 'label', 'icon', 'isNew' => false]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['tab', 'label', 'icon', 'isNew' => false]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>

<a
    href="<?php echo e(route('profile', ['tab' => $tab])); ?>"
    role="tab"
    aria-controls="panel-<?php echo e($tab); ?>"
    @click.prevent="activeTab = '<?php echo e($tab); ?>'; window.history.pushState({}, '', '?tab=<?php echo e($tab); ?>')"
    :aria-selected="activeTab === '<?php echo e($tab); ?>' ? 'true' : 'false'"
    class="flex items-center gap-3.5 px-4 py-3.5 text-xs font-black transition-all rounded-[1.25rem] group w-full relative tracking-widest uppercase"
    :class="activeTab === '<?php echo e($tab); ?>' 
        ? 'shadow-skeuo-inset bg-white/80 dark:bg-gray-900/40 text-red-600 scale-[0.98]' 
        : 'text-gray-500 dark:text-gray-400 hover:bg-white/40 dark:hover:bg-gray-800/40'"
>
    <div 
        class="w-9 h-9 rounded-xl flex items-center justify-center transition-all duration-300"
        :class="activeTab === '<?php echo e($tab); ?>' ? 'bg-gradient-to-br from-red-500 to-red-600 text-white shadow-lg shadow-red-500/20 scale-105' : 'bg-gray-50 dark:bg-gray-900 text-gray-400 group-hover:bg-white dark:group-hover:bg-gray-800 group-hover:scale-105 shadow-sm'"
    >
        <svg class="w-4.5 h-4.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5" d="<?php echo e($icon); ?>"></path>
        </svg>
    </div>
    
    <span class="flex-1 tracking-[0.1em]"><?php echo e($label); ?></span>
    
    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($isNew): ?>
        <span class="bg-red-500 text-[9px] text-white px-2 py-0.5 rounded-full font-black uppercase tracking-tighter shadow-sm group-hover:animate-pulse border border-white/20">
            <?php echo e(__('profile.new')); ?>

        </span>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

    <div 
        x-show="activeTab === '<?php echo e($tab); ?>'"
        x-transition:enter="transition ease-out duration-300"
        x-transition:enter-start="opacity-0 scale-y-0"
        x-transition:enter-end="opacity-100 scale-y-100"
        class="absolute left-0 w-1.5 h-7 bg-red-600 rounded-r-full shadow-[0_0_12px_rgba(239,68,68,0.4)]"
    ></div>
</a>
<?php /**PATH /Users/dwipurwanto/Sites/sites/freelance/event-management/resources/views/components/profile/nav-item.blade.php ENDPATH**/ ?>